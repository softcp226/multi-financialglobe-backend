// document.addEventListener("DOMContentLoaded",()=>   container.classList.add("right-panel-active"))
  


document.addEventListener("DOMContentLoaded",()=>   container.classList.add("right-panel-active"))
  

