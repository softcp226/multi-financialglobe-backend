// (() => {
//   if (
//     window.location.href.includes("http://www.panteramining.com") ||
//     window.location.href.includes("http://panteramining.com")
//   ) {
//     window.location.replace("https://www.panteramining.com");
//   }
// })();
