document.querySelector("#handlenav").onclick=()=>{
    if(document.querySelector(".nav-text-container-hide"))return document.querySelector(".nav-text-container-hide").className="nav-text-container"
  document.querySelector("#nav-text-container").className="nav-text-container-hide"
}